"""전역 애플리케이션 상태 관리."""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AppState:
    """애플리케이션 전역 상태."""
    
    # 통계 정보
    total_files: int = 0
    processed_files: int = 0
    saved_size_gb: float = 0.0
    
    # 현재 선택된 탭
    current_tab: str = "scan"
    
    # 스캔 상태
    scan_folder: Optional[str] = None
    is_scanning: bool = False
    
    def update_stats(self, total: int, processed: int, saved_gb: float) -> None:
        """통계 정보 업데이트."""
        self.total_files = total
        self.processed_files = processed
        self.saved_size_gb = saved_gb
