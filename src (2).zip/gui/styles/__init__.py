"""GUI Styles Package."""
