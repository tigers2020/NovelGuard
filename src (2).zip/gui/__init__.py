"""NovelGuard GUI Package."""
