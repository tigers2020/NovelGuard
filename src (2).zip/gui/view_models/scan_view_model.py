"""스캔 탭 ViewModel."""
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject

from gui.view_models.base_view_model import BaseViewModel


class ScanViewModel(BaseViewModel):
    """스캔 탭 ViewModel."""
    
    def __init__(self, parent: Optional[QObject] = None) -> None:
        """스캔 ViewModel 초기화."""
        super().__init__(parent)
        
        # 상태
        self._scan_folder: Optional[Path] = None
        self._is_scanning: bool = False
        self._progress: int = 0
        self._progress_message: str = ""
        
        # 설정
        self._extension_filter: str = ""
        self._include_subdirs: bool = True
        self._incremental_scan: bool = True
        self._include_hidden: bool = False
        self._include_symlinks: bool = True
    
    def load_data(self) -> None:
        """데이터 로드."""
        # TODO: 실제 데이터 로드 로직 (UseCase 호출)
        pass
    
    @property
    def scan_folder(self) -> Optional[Path]:
        """스캔 폴더 반환."""
        return self._scan_folder
    
    @scan_folder.setter
    def scan_folder(self, value: Optional[Path]) -> None:
        """스캔 폴더 설정."""
        self._scan_folder = value
        self.data_changed.emit()
    
    @property
    def is_scanning(self) -> bool:
        """스캔 중 여부 반환."""
        return self._is_scanning
    
    @property
    def progress(self) -> int:
        """진행률 반환 (0-100)."""
        return self._progress
    
    @property
    def progress_message(self) -> str:
        """진행 메시지 반환."""
        return self._progress_message
    
    def start_scan(self, folder: Path, extensions: str = "", **options) -> None:
        """스캔 시작."""
        if self._is_scanning:
            return
        
        self._scan_folder = folder
        self._extension_filter = extensions
        self._include_subdirs = options.get("include_subdirs", True)
        self._incremental_scan = options.get("incremental_scan", True)
        self._include_hidden = options.get("include_hidden", False)
        self._include_symlinks = options.get("include_symlinks", True)
        
        self._is_scanning = True
        self._progress = 0
        self._progress_message = "스캔 시작 중..."
        
        # TODO: 실제 스캔 로직 호출 (UseCase)
        # scan_usecase = ...
        # result = scan_usecase.execute(...)
        
        self.data_changed.emit()
        self.progress_updated.emit(0, "스캔 시작 중...")
    
    def stop_scan(self) -> None:
        """스캔 중지."""
        if not self._is_scanning:
            return
        
        self._is_scanning = False
        self._progress_message = "스캔 중지됨"
        
        # TODO: 실제 스캔 중지 로직 호출
        
        self.data_changed.emit()
        self.progress_updated.emit(self._progress, "스캔 중지됨")
    
    def update_progress(self, progress: int, message: str) -> None:
        """진행률 업데이트."""
        self._progress = progress
        self._progress_message = message
        self.progress_updated.emit(progress, message)
