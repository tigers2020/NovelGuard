"""파일 스캔 탭."""
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from gui.views.tabs.base_tab import BaseTab


class ScanTab(BaseTab):
    """파일 스캔 탭."""
    
    folder_selected = Signal(Path)
    """폴더 선택 시그널."""
    
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        """스캔 탭 초기화."""
        self._scan_folder: Optional[Path] = None
        super().__init__(parent)
    
    def get_title(self) -> str:
        """페이지 제목 반환."""
        return "📁 파일 스캔"
    
    def _setup_content(self, layout: QVBoxLayout) -> None:
        """컨텐츠 설정."""
        # 액션 바
        action_bar = self._create_action_bar()
        layout.addLayout(action_bar)
        
        # 프로그레스 섹션
        self._progress_section = self._create_progress_section()
        layout.addWidget(self._progress_section)
        
        # 설정 그룹
        settings_group = self._create_settings_group()
        layout.addWidget(settings_group)
    
    def _create_action_bar(self) -> QHBoxLayout:
        """액션 바 생성."""
        layout = QHBoxLayout()
        layout.setSpacing(16)
        
        # 폴더 선택 버튼
        folder_btn = QPushButton("📂 폴더 선택")
        folder_btn.setObjectName("btnPrimary")
        folder_btn.clicked.connect(self._on_select_folder)
        layout.addWidget(folder_btn)
        
        # 스캔 시작 버튼
        scan_btn = QPushButton("▶ 스캔 시작")
        scan_btn.setObjectName("btnPrimary")
        scan_btn.clicked.connect(self._on_start_scan)
        layout.addWidget(scan_btn)
        
        # 중지 버튼
        stop_btn = QPushButton("중지")
        stop_btn.setObjectName("btnSecondary")
        stop_btn.clicked.connect(self._on_stop_scan)
        layout.addWidget(stop_btn)
        
        layout.addStretch()
        
        return layout
    
    def _create_progress_section(self) -> QGroupBox:
        """프로그레스 섹션 생성."""
        group = QGroupBox()
        group.setTitle("")
        
        layout = QVBoxLayout(group)
        layout.setSpacing(12)
        
        # 프로그레스 헤더
        progress_header = QHBoxLayout()
        progress_header.setContentsMargins(0, 0, 0, 0)
        
        progress_title = QLabel("스캔 진행 중...")
        progress_title.setObjectName("progressTitle")
        progress_header.addWidget(progress_title)
        
        progress_header.addStretch()
        
        self._progress_percent = QLabel("0%")
        self._progress_percent.setObjectName("progressPercent")
        progress_header.addWidget(self._progress_percent)
        
        layout.addLayout(progress_header)
        
        # 프로그레스 바
        self._progress_bar = QProgressBar()
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_bar.setTextVisible(False)
        layout.addWidget(self._progress_bar)
        
        # 프로그레스 정보
        self._progress_info = QLabel("대기 중...")
        self._progress_info.setObjectName("progressInfo")
        self._progress_info.setStyleSheet("font-size: 12px; color: #808080;")
        layout.addWidget(self._progress_info)
        
        # 항상 보이도록 설정
        group.setVisible(True)
        
        return group
    
    def _create_settings_group(self) -> QGroupBox:
        """설정 그룹 생성."""
        group = QGroupBox("스캔 설정")
        group.setObjectName("settingsGroup")
        
        layout = QVBoxLayout(group)
        layout.setSpacing(20)
        
        # 대상 폴더
        folder_layout = QVBoxLayout()
        folder_layout.setSpacing(8)
        
        folder_label = QLabel("대상 폴더")
        folder_label.setObjectName("formLabel")
        folder_layout.addWidget(folder_label)
        
        self._folder_input = QLineEdit()
        self._folder_input.setReadOnly(True)
        self._folder_input.setPlaceholderText("폴더를 선택하세요")
        folder_layout.addWidget(self._folder_input)
        
        layout.addLayout(folder_layout)
        
        # 파일 확장자 필터
        extension_layout = QVBoxLayout()
        extension_layout.setSpacing(8)
        
        extension_label = QLabel("파일 확장자 필터")
        extension_label.setObjectName("formLabel")
        extension_layout.addWidget(extension_label)
        
        self._extension_input = QLineEdit()
        self._extension_input.setPlaceholderText(".txt, .md, .log (비어있으면 모든 텍스트 파일)")
        extension_layout.addWidget(self._extension_input)
        
        layout.addLayout(extension_layout)
        
        # 스캔 옵션
        options_label = QLabel("스캔 옵션")
        options_label.setObjectName("formLabel")
        layout.addWidget(options_label)
        
        # 체크박스 그룹
        checkbox_layout = QVBoxLayout()
        checkbox_layout.setSpacing(12)
        
        self._include_subdirs = QCheckBox("하위 폴더 포함")
        self._include_subdirs.setChecked(True)
        checkbox_layout.addWidget(self._include_subdirs)
        
        self._incremental_scan = QCheckBox("증분 스캔")
        self._incremental_scan.setChecked(True)
        checkbox_layout.addWidget(self._incremental_scan)
        
        self._include_hidden = QCheckBox("숨김 파일 포함")
        checkbox_layout.addWidget(self._include_hidden)
        
        self._include_symlinks = QCheckBox("심볼릭 링크")
        self._include_symlinks.setChecked(True)
        checkbox_layout.addWidget(self._include_symlinks)
        
        layout.addLayout(checkbox_layout)
        
        return group
    
    def _on_select_folder(self) -> None:
        """폴더 선택 핸들러."""
        folder = QFileDialog.getExistingDirectory(
            self,
            "스캔할 폴더 선택",
            str(self._scan_folder) if self._scan_folder else ""
        )
        
        if folder:
            folder_path = Path(folder)
            self.set_scan_folder(folder_path)
            # 시그널 emit하여 MainWindow가 preview scan을 시작하도록
            self.folder_selected.emit(folder_path)
    
    def set_scan_folder(self, folder: Path) -> None:
        """스캔 폴더 설정.
        
        Args:
            folder: 설정할 폴더 경로.
        """
        self._scan_folder = folder
        self._folder_input.setText(str(self._scan_folder))
    
    def get_scan_folder(self) -> Optional[Path]:
        """스캔 폴더 반환.
        
        Returns:
            현재 설정된 스캔 폴더. 없으면 None.
        """
        return self._scan_folder
    
    def get_extension_filter(self) -> str:
        """확장자 필터 반환.
        
        Returns:
            확장자 필터 문자열 (예: ".txt, .md, .log").
        """
        return self._extension_input.text().strip()
    
    def get_include_subdirs(self) -> bool:
        """하위 폴더 포함 여부 반환.
        
        Returns:
            하위 폴더 포함 여부.
        """
        return self._include_subdirs.isChecked()
    
    def get_include_hidden(self) -> bool:
        """숨김 파일 포함 여부 반환.
        
        Returns:
            숨김 파일 포함 여부.
        """
        return self._include_hidden.isChecked()
    
    def get_include_symlinks(self) -> bool:
        """심볼릭 링크 포함 여부 반환.
        
        Returns:
            심볼릭 링크 포함 여부.
        """
        return self._include_symlinks.isChecked()
    
    def _on_start_scan(self) -> None:
        """스캔 시작 핸들러."""
        if not self._scan_folder:
            # TODO: 에러 메시지 표시
            return
        
        # TODO: 실제 스캔 로직 호출
        print(f"스캔 시작: {self._scan_folder}")
    
    def _on_stop_scan(self) -> None:
        """스캔 중지 핸들러."""
        # TODO: 실제 스캔 중지 로직 호출
        print("스캔 중지")
