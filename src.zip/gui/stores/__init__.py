"""ResultStore(AppState)."""

