"""QRunnable/QThread worker."""

