"""QWidget/QMainWindow."""

