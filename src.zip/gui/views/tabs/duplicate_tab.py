"""중복 파일 정리 탭."""
from typing import Optional

from PySide6.QtWidgets import (
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from application.ports.index_repository import IIndexRepository
from application.ports.job_runner import IJobRunner
from application.ports.log_sink import ILogSink
from application.utils.debug_logger import debug_step
from gui.models.app_state import AppState
from gui.view_models.duplicate_view_model import DuplicateViewModel
from gui.views.tabs.base_tab import BaseTab


class DuplicateTab(BaseTab):
    """중복 파일 정리 탭."""
    
    def __init__(
        self,
        parent: Optional[QWidget] = None,
        job_manager: Optional[IJobRunner] = None,
        index_repository: Optional[IIndexRepository] = None,
        log_sink: Optional[ILogSink] = None
    ) -> None:
        """중복 탭 초기화.
        
        Args:
            parent: 부모 위젯.
            job_manager: Job 관리자 (선택적).
            index_repository: 인덱스 저장소 (선택적).
            log_sink: 로그 싱크 (선택적).
        """
        self._job_manager = job_manager
        self._index_repository = index_repository
        self._log_sink = log_sink
        
        debug_step(self._log_sink, "duplicate_tab_init")
        
        # ViewModel을 먼저 생성
        self._view_model = DuplicateViewModel(
            parent=None,
            job_manager=job_manager,
            index_repository=index_repository,
            log_sink=log_sink
        )
        
        self._app_state: Optional[AppState] = None
        
        super().__init__(parent)
        
        # AppState 가져오기
        self._app_state = self._get_app_state()
        
        # ViewModel의 parent 설정
        self._view_model.setParent(self)
        
        # ViewModel 시그널 연결 (컴포넌트와 무관한 시그널만)
        self._view_model.progress_updated.connect(self._on_progress_updated)
        self._view_model.duplicate_completed.connect(self._on_duplicate_completed)
        self._view_model.duplicate_error.connect(self._on_duplicate_error)
        self._view_model.results_updated.connect(self._on_results_updated)
    
    def _get_app_state(self) -> AppState:
        """AppState 가져오기."""
        parent = self.parent()
        while parent:
            if hasattr(parent, '_app_state'):
                return parent._app_state
            parent = parent.parent()
        # 기본값으로 새로 생성
        return AppState()
    
    def get_title(self) -> str:
        """페이지 제목 반환."""
        return "🔍 중복 파일 정리"
    
    def _setup_content(self, layout: QVBoxLayout) -> None:
        """컨텐츠 설정."""
        # AppState 가져오기 (super().__init__ 이후이므로 가능)
        if self._app_state is None:
            self._app_state = self._get_app_state()
        
        # 액션 바
        action_bar = self._create_action_bar()
        layout.addLayout(action_bar)
        
        # 프로그레스 섹션
        self._progress_section = self._create_progress_section()
        layout.addWidget(self._progress_section)
    
    def _create_action_bar(self) -> QHBoxLayout:
        """액션 바 생성."""
        layout = QHBoxLayout()
        layout.setSpacing(16)
        
        detect_btn = QPushButton("중복 탐지 시작")
        detect_btn.setObjectName("btnPrimary")
        detect_btn.clicked.connect(self._on_start_detection)
        layout.addWidget(detect_btn)
        
        dry_run_btn = QPushButton("Dry Run")
        dry_run_btn.setObjectName("btnSecondary")
        layout.addWidget(dry_run_btn)
        
        apply_btn = QPushButton("적용하기")
        apply_btn.setObjectName("btnSuccess")
        layout.addWidget(apply_btn)
        
        layout.addStretch()
        
        return layout
    
    def _create_progress_section(self) -> QGroupBox:
        """프로그레스 섹션 생성."""
        group = QGroupBox()
        group.setTitle("")
        
        layout = QVBoxLayout(group)
        layout.setSpacing(12)
        
        # 프로그레스 헤더
        progress_header = QHBoxLayout()
        progress_header.setContentsMargins(0, 0, 0, 0)
        
        progress_title = QLabel("중복 탐지 진행 중...")
        progress_title.setObjectName("progressTitle")
        progress_header.addWidget(progress_title)
        
        progress_header.addStretch()
        
        self._progress_percent = QLabel("0%")
        self._progress_percent.setObjectName("progressPercent")
        progress_header.addWidget(self._progress_percent)
        
        layout.addLayout(progress_header)
        
        # 프로그레스 바
        self._progress_bar = QProgressBar()
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_bar.setTextVisible(False)
        layout.addWidget(self._progress_bar)
        
        # 프로그레스 정보
        self._progress_info = QLabel("대기 중...")
        self._progress_info.setObjectName("progressInfo")
        self._progress_info.setStyleSheet("font-size: 12px; color: #808080;")
        layout.addWidget(self._progress_info)
        
        # 항상 보이도록 설정
        group.setVisible(True)
        
        return group
    
    def _on_start_detection(self) -> None:
        """중복 탐지 시작 버튼 핸들러."""
        debug_step(self._log_sink, "duplicate_tab_start_detection")
        self._view_model.start_duplicate_detection()
    
    def _on_progress_updated(self, progress: int, message: str) -> None:
        """진행률 업데이트 핸들러."""
        # Indeterminate 진행률
        self._progress_bar.setRange(0, 0)
        self._progress_info.setText(message)
        self._progress_percent.setText("")
    
    def _on_duplicate_completed(self, results: list) -> None:
        """중복 탐지 완료 핸들러."""
        debug_step(
            self._log_sink,
            "duplicate_tab_completed",
            {"results_count": len(results)}
        )
        
        # 프로그레스 바를 normal 모드로 복원
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(100)
        self._progress_percent.setText("100%")
        self._progress_info.setText(f"완료: {len(results)}개 그룹")
        
        # FileDataStore에 중복 그룹 정보 마킹 (배치 처리로 UI 프리징 방지)
        if self._app_state:
            file_data_store = self._app_state.file_data_store
            
            # 배치 업데이트를 위한 업데이트 리스트 생성
            batch_updates = []
            for result in results:
                # evidence에서 similarity 추출 (near duplicate의 경우)
                evidence = result.evidence or {}
                similarity_score = None
                if result.duplicate_type == "near":
                    # near duplicate인 경우 evidence에서 similarity 값 추출
                    similarity_score = evidence.get("similarity")
                    if similarity_score is None:
                        # fallback: confidence를 similarity로 사용 (정확도 낮음)
                        similarity_score = result.confidence
                
                for file_id in result.file_ids:
                    is_canonical = (file_id == result.recommended_keeper_id) if result.recommended_keeper_id else False
                    batch_updates.append((
                        file_id,
                        result.group_id,
                        is_canonical,
                        similarity_score  # confidence가 아닌 실제 similarity 값 사용
                    ))
            
            # 배치 업데이트 (시그널을 한 번만 emit하여 UI 프리징 방지)
            if batch_updates:
                file_data_store.set_duplicate_groups_batch(batch_updates)
    
    def _on_duplicate_error(self, error_message: str) -> None:
        """중복 탐지 오류 핸들러."""
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_percent.setText("0%")
        self._progress_info.setText(f"오류: {error_message}")
    
    def _on_results_updated(self) -> None:
        """결과 업데이트 핸들러."""
        # FileListTableWidget이 FileDataStore 시그널을 통해 자동으로 업데이트됨
        pass
    