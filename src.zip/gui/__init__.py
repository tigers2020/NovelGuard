"""
NovelGuard GUI 모듈
"""

