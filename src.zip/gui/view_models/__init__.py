"""GUI ViewModels Package."""
from gui.view_models.duplicate_view_model import DuplicateViewModel

__all__ = [
    "DuplicateViewModel",
]
