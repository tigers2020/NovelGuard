"""ResultEventRouter, UIBatcher."""

