"""Badge 렌더링."""

