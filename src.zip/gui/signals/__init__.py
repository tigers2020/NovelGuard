"""Qt Signals 정의."""

