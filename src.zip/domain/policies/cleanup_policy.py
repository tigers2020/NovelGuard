"""정리 정책/필터 정책."""

from typing import Callable
from domain.models.file_record import FileRecord
from domain.models.action_plan import ActionPlan, ActionItem


class CleanupPolicy:
    """정리 정책.
    
    파일 정리를 위한 규칙 및 필터.
    """
    
    @staticmethod
    def should_delete_duplicate(
        record: FileRecord,
        is_canonical: bool = False
    ) -> bool:
        """중복 파일 삭제 여부 판정.
        
        Args:
            record: 파일 레코드
            is_canonical: canonical 파일 여부
        
        Returns:
            삭제 여부 (canonical이 아니면 삭제)
        """
        return not is_canonical
    
    @staticmethod
    def should_delete_small_file(
        record: FileRecord,
        min_size_bytes: int = 1024
    ) -> bool:
        """작은 파일 삭제 여부 판정.
        
        Args:
            record: 파일 레코드
            min_size_bytes: 최소 크기 (bytes)
        
        Returns:
            삭제 여부
        """
        return record.size < min_size_bytes
    
    @staticmethod
    def should_convert_encoding(
        record: FileRecord,
        target_encoding: str = "UTF-8"
    ) -> bool:
        """인코딩 변환 여부 판정.
        
        Args:
            record: 파일 레코드
            target_encoding: 대상 인코딩
        
        Returns:
            변환 여부
        """
        if not record.is_text:
            return False
        
        if not record.encoding_detected:
            return False
        
        return record.encoding_detected.upper() != target_encoding.upper()

