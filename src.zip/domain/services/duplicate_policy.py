"""중복 판정 정책."""

from typing import Optional
from domain.models.file_record import FileRecord


class DuplicatePolicy:
    """중복 판정 규칙.
    
    두 파일이 중복인지, 유사한지 판정하는 정책.
    """
    
    @staticmethod
    def is_exact_duplicate(record_a: FileRecord, record_b: FileRecord) -> bool:
        """완전 중복 판정.
        
        Args:
            record_a: 파일 A 레코드
            record_b: 파일 B 레코드
        
        Returns:
            완전 중복 여부
        """
        # 강한 해시가 모두 있고 같으면 완전 중복
        if record_a.hash_strong and record_b.hash_strong:
            return record_a.hash_strong == record_b.hash_strong
        
        # 정규화 지문이 모두 있고 같으면 완전 중복
        if record_a.fingerprint_norm and record_b.fingerprint_norm:
            return record_a.fingerprint_norm == record_b.fingerprint_norm
        
        return False
    
    @staticmethod
    def is_similar(
        record_a: FileRecord,
        record_b: FileRecord,
        threshold: float = 0.95
    ) -> bool:
        """유사도 기반 판정.
        
        Args:
            record_a: 파일 A 레코드
            record_b: 파일 B 레코드
            threshold: 유사도 임계값 (0.0 ~ 1.0)
        
        Returns:
            유사 여부
        """
        # SimHash가 모두 있으면 SimHash 거리로 판정
        if record_a.simhash64 is not None and record_b.simhash64 is not None:
            # Hamming distance 계산
            distance = bin(record_a.simhash64 ^ record_b.simhash64).count('1')
            # 64bit SimHash 기준 유사도 = 1 - (distance / 64)
            similarity = 1.0 - (distance / 64.0)
            return similarity >= threshold
        
        # 빠른 지문이 모두 있고 같으면 유사로 판정
        if record_a.fingerprint_fast and record_b.fingerprint_fast:
            if record_a.fingerprint_fast == record_b.fingerprint_fast:
                return True
        
        return False
    
    @staticmethod
    def is_containment(
        record_a: FileRecord,
        record_b: FileRecord
    ) -> tuple[bool, Optional[str]]:
        """포함 관계 판정.
        
        Args:
            record_a: 파일 A 레코드
            record_b: 파일 B 레코드
        
        Returns:
            (포함 관계 여부, 포함 방향: "A_IN_B" | "B_IN_A" | None)
        """
        # 크기 비교로 포함 관계 추정 (실제 구현은 텍스트 비교 필요)
        if record_a.size < record_b.size:
            # A가 B에 포함될 가능성
            return True, "A_IN_B"
        elif record_b.size < record_a.size:
            # B가 A에 포함될 가능성
            return True, "B_IN_A"
        
        return False, None

