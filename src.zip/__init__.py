"""NovelGuard - 텍스트 소설 파일 정리 도구."""

__version__ = "1.0.0"

