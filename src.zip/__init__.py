"""NovelGuard Source Package."""
