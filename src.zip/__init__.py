"""
NovelGuard 프로젝트 메인 패키지
"""

__version__ = "0.1.0"

