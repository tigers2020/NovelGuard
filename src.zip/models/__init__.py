"""
NovelGuard 모델 모듈

데이터 모델 정의를 포함합니다.
"""

from .file_record import FileRecord

__all__ = ["FileRecord"]

