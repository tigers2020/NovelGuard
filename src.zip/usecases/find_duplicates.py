"""중복 탐지 유스케이스."""

from typing import Callable, Optional
from infra.db.file_repository import FileRepository
from domain.models.duplicate_group import DuplicateGroup
from domain.models.evidence import Evidence
from domain.services.duplicate_policy import DuplicatePolicy
from domain.services.canonical_selector import CanonicalSelector
from common.logging import setup_logging

logger = setup_logging()


class FindDuplicatesUseCase:
    """중복 탐지 유스케이스."""
    
    def __init__(
        self,
        repository: FileRepository,
        policy: Optional[DuplicatePolicy] = None,
        selector: Optional[CanonicalSelector] = None
    ) -> None:
        """유스케이스 초기화.
        
        Args:
            repository: FileRepository
            policy: DuplicatePolicy (None이면 기본값)
            selector: CanonicalSelector (None이면 기본값)
        """
        self.repository = repository
        self.policy = policy or DuplicatePolicy()
        self.selector = selector or CanonicalSelector()
    
    def execute(
        self,
        similarity_threshold: float = 0.95,
        progress_callback: Optional[Callable[[int, int], None]] = None
    ) -> list[DuplicateGroup]:
        """중복 탐지 실행.
        
        Args:
            similarity_threshold: 유사도 임계값
            progress_callback: 진행 상황 콜백
        
        Returns:
            DuplicateGroup 리스트
        """
        records = list(self.repository.list_all())
        groups = []
        processed = set()
        group_id = 1
        
        total = len(records)
        
        for idx, record_a in enumerate(records):
            if record_a.file_id in processed:
                continue
            
            if progress_callback:
                progress_callback(idx + 1, total)
            
            # 같은 해시를 가진 파일 찾기
            duplicates = [record_a]
            for record_b in records:
                if record_b.file_id == record_a.file_id:
                    continue
                if record_b.file_id in processed:
                    continue
                
                if self.policy.is_exact_duplicate(record_a, record_b):
                    duplicates.append(record_b)
                    processed.add(record_b.file_id)
            
            if len(duplicates) > 1:
                # Canonical 선택
                canonical = self.selector.select_canonical(duplicates)
                
                group = DuplicateGroup(
                    group_id=group_id,
                    group_type="EXACT",
                    member_ids=[r.file_id for r in duplicates],
                    canonical_id=canonical.file_id if canonical else None,
                    confidence=1.0,
                    status="CANDIDATE"
                )
                groups.append(group)
                group_id += 1
                processed.add(record_a.file_id)
        
        return groups

