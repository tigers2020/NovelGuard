"""앱 조립(bootstrap), DI, 설정 로딩."""

