"""NovelGuard Application Package."""
