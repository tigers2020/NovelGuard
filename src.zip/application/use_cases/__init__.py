"""애플리케이션 UseCase 모듈."""
